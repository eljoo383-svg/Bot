// تعريف إعدادات القناة (الـ JID المطلوب) بشكل احترافي
const vipChannel = { 
    contextInfo: { 
        forwardingScore: 999, 
        isForwarded: true, 
        forwardedNewsletterMessageInfo: { 
            newsletterJid: '120363405610374694@newsletter', 
            newsletterName: 'VIP SYSTEM', 
            serverMessageId: 1 
        } 
    } 
};

async function clearCommand(sock, chatId) {
    try {
        // رسالة التنبيه قبل المسح بلهجة مصرية VIP
        const message = await sock.sendMessage(chatId, { 
            text: '✨ | جاري تنظيف الشات من رسايل البوت.. لحظة واحدة يا غالي! 🧹💫',
            ...vipChannel 
        });

        const messageKey = message.key; // الحصول على مفتاح الرسالة
        
        // مسح رسالة البوت فوراً
        await sock.sendMessage(chatId, { delete: messageKey });
        
    } catch (error) {
        console.error('Error clearing messages:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ | معلش يا حب، حصلت مشكلة وأنا بنضف الشات.. جرب تاني! ⚙️⚠️',
            ...vipChannel 
        });
    }
}

module.exports = { clearCommand };
