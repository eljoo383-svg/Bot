const { handleWelcome } = require('../lib/welcome');
const { isWelcomeOn, getWelcome } = require('../lib/index');
const { channelInfo } = require('../lib/messageConfig');
const fetch = require('node-fetch');

async function welcomeCommand(sock, chatId, message, match) {
    // التحقق من أنها مجموعة
    if (!chatId.endsWith('@g.us')) {
        await sock.sendMessage(chatId, { text: 'هذا الأمر يعمل فقط داخل المجموعات.' });
        return;
    }

    const text = message.message?.conversation || 
                message.message?.extendedTextMessage?.text || '';
    const matchText = text.split(' ').slice(1).join(' ');

    await handleWelcome(sock, chatId, message, matchText);
}

async function handleJoinEvent(sock, id, participants) {
    const isWelcomeEnabled = await isWelcomeOn(id);
    if (!isWelcomeEnabled) return;

    const customMessage = await getWelcome(id);
    const groupMetadata = await sock.groupMetadata(id);
    const groupName = groupMetadata.subject;
    const groupDesc = groupMetadata.desc || 'لا يوجد وصف متاح';

    for (const participant of participants) {
        try {
            const participantString = typeof participant === 'string' ? participant : (participant.id || participant.toString());
            const user = participantString.split('@')[0];
            
            let displayName = user; 
            try {
                const contact = await sock.getBusinessProfile(participantString);
                if (contact && contact.name) {
                    displayName = contact.name;
                }
            } catch (nameError) {
                console.log('Could not fetch name, using ID');
            }
            
            let finalMessage;
            if (customMessage) {
                finalMessage = customMessage
                    .replace(/{user}/g, `@${user}`)
                    .replace(/{group}/g, groupName)
                    .replace(/{description}/g, groupDesc);
            } else {
                const now = new Date();
                const timeString = now.toLocaleString('ar-EG', {
                    hour: '2-digit',
                    minute: '2-digit',
                    hour12: true
                });
                
                finalMessage = `╭╼━≪• نـور الـمـجـمـوعـة •≫━╾╮\n┃ الـمـنـور: @${user} 👋\n┃ رقـم الـعـضـو: #${groupMetadata.participants.length}\n┃ الـوقـت: ${timeString} ⏰\n╰━━━━━━━━━━━━━━━╯\n\n*أهلاً بك يا @${user}* في جروب *${groupName}*! 🎉\n\n*وصف المجموعة:*\n${groupDesc}\n\n> *تطوير: Elmasry Bot 🤖*`;
            }
            
            // إعداد الـ contextInfo لإضافة رابط رقمك
            const myContextInfo = {
                externalAdReply: {
                    title: "Elmasry Bot Welcome",
                    body: "تواصل مع المطور",
                    thumbnailUrl: "https://i.imgur.com/2wzGhpF.jpeg", // يمكنك تغييرها لصورة الترحيب
                    sourceUrl: "https://wa.me/201013815156", // رابط رقمك
                    mediaType: 1,
                    renderLargerThumbnail: false
                }
            };

            try {
                let profilePicUrl = `https://img.pyrocdn.com/dbKUgahg.png`; 
                try {
                    const profilePic = await sock.profilePictureUrl(participantString, 'image');
                    if (profilePic) profilePicUrl = profilePic;
                } catch (e) {}
                
                const apiUrl = `https://api.some-random-api.com/welcome/img/2/gaming3?type=join&textcolor=green&username=${encodeURIComponent(user)}&guildName=${encodeURIComponent(groupName)}&memberCount=${groupMetadata.participants.length}&avatar=${encodeURIComponent(profilePicUrl)}`;
                
                const response = await fetch(apiUrl);
                if (response.ok) {
                    const imageBuffer = await response.buffer();
                    await sock.sendMessage(id, {
                        image: imageBuffer,
                        caption: finalMessage,
                        mentions: [participantString],
                        contextInfo: myContextInfo
                    });
                    continue;
                }
            } catch (imageError) {
                console.log('Falling back to text');
            }
            
            await sock.sendMessage(id, {
                text: finalMessage,
                mentions: [participantString],
                contextInfo: myContextInfo
            });
        } catch (error) {
            console.error('Error sending welcome message:', error);
        }
    }
}

module.exports = { welcomeCommand, handleJoinEvent };
