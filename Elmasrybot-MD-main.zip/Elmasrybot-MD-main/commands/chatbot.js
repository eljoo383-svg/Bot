const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');

const USER_GROUP_DATA = path.join(__dirname, '../data/userGroupData.json');

// مخزن مؤقت في الذاكرة لتاريخ الدردشة ومعلومات المستخدم
const chatMemory = {
    messages: new Map(), // يخزن آخر 5 رسائل لكل مستخدم
    userInfo: new Map()  // يخزن معلومات المستخدم
};

// تحميل بيانات المجموعات
function loadUserGroupData() {
    try {
        return JSON.parse(fs.readFileSync(USER_GROUP_DATA));
    } catch (error) {
        console.error('❌ خطأ في تحميل بيانات المجموعات:', error.message);
        return { groups: [], chatbot: {} };
    }
}

// حفظ بيانات المجموعات
function saveUserGroupData(data) {
    try {
        fs.writeFileSync(USER_GROUP_DATA, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error('❌ خطأ في حفظ بيانات المجموعات:', error.message);
    }
}

// إضافة تأخير عشوائي بين 2-5 ثوانٍ
function getRandomDelay() {
    return Math.floor(Math.random() * 3000) + 2000;
}

// إضافة مؤشر "جاري الكتابة"
async function showTyping(sock, chatId) {
    try {
        await sock.presenceSubscribe(chatId);
        await sock.sendPresenceUpdate('composing', chatId);
        await new Promise(resolve => setTimeout(resolve, getRandomDelay()));
    } catch (error) {
        console.error('خطأ في مؤشر الكتابة:', error);
    }
}

// استخراج معلومات المستخدم من الرسائل
function extractUserInfo(message) {
    const info = {};
    
    // استخراج الاسم (يدعم: اسمي هو / أنا اسمي)
    if (message.toLowerCase().includes('اسمي هو') || message.toLowerCase().includes('أنا اسمي')) {
        info.name = message.split(/(?:اسمي هو|أنا اسمي)/i)[1].trim().split(' ')[0];
    }
    
    // استخراج العمر
    if (message.includes('عمري') || (message.includes('سنة') && message.match(/\d+/))) {
        info.age = message.match(/\d+/)?.[0];
    }
    
    // استخراج الموقع
    if (message.includes('أعيش في') || message.includes('أنا من')) {
        info.location = message.split(/(?:أعيش في|أنا من)/i)[1].trim().split(/[.,!?]/)[0];
    }
    
    return info;
}

async function handleChatbotCommand(sock, chatId, message, match) {
    if (!match) {
        await showTyping(sock, chatId);
        return sock.sendMessage(chatId, {
            text: `*إعدادات البوت الآلي*\n\n*.chatbot on*\nلتفعيل البوت\n\n*.chatbot off*\nلتعطيل البوت في هذه المجموعة`,
            quoted: message
        });
    }

    const data = loadUserGroupData();
    
    const botNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const senderId = message.key.participant || message.participant || message.pushName || message.key.remoteJid;
    const isOwner = senderId === botNumber;

    if (isOwner) {
        if (match === 'on') {
            await showTyping(sock, chatId);
            if (data.chatbot[chatId]) {
                return sock.sendMessage(chatId, { 
                    text: '*البوت مفعل بالفعل في هذه المجموعة*',
                    quoted: message
                });
            }
            data.chatbot[chatId] = true;
            saveUserGroupData(data);
            console.log(`✅ تم تفعيل البوت للمجموعة ${chatId}`);
            return sock.sendMessage(chatId, { 
                text: '*تم تفعيل البوت الآلي لهذه المجموعة بنجاح ✅*',
                quoted: message
            });
        }

        if (match === 'off') {
            await showTyping(sock, chatId);
            if (!data.chatbot[chatId]) {
                return sock.sendMessage(chatId, { 
                    text: '*البوت معطل بالفعل في هذه المجموعة*',
                    quoted: message
                });
            }
            delete data.chatbot[chatId];
            saveUserGroupData(data);
            console.log(`✅ تم تعطيل البوت للمجموعة ${chatId}`);
            return sock.sendMessage(chatId, { 
                text: '*تم تعطيل البوت الآلي لهذه المجموعة ❌*',
                quoted: message
            });
        }
    }

    let isAdmin = false;
    if (chatId.endsWith('@g.us')) {
        try {
            const groupMetadata = await sock.groupMetadata(chatId);
            isAdmin = groupMetadata.participants.some(p => p.id === senderId && (p.admin === 'admin' || p.admin === 'superadmin'));
        } catch (e) {
            console.warn('⚠️ تعذر جلب بيانات المجموعة.');
        }
    }

    if (!isAdmin && !isOwner) {
        await showTyping(sock, chatId);
        return sock.sendMessage(chatId, {
            text: '❌ عذراً، هذا الأمر متاح فقط لمشرفي المجموعة أو مالك البوت.',
            quoted: message
        });
    }

    if (match === 'on') {
        await showTyping(sock, chatId);
        if (data.chatbot[chatId]) {
            return sock.sendMessage(chatId, { 
                text: '*البوت مفعل بالفعل في هذه المجموعة*',
                quoted: message
            });
        }
        data.chatbot[chatId] = true;
        saveUserGroupData(data);
        return sock.sendMessage(chatId, { 
            text: '*تم تفعيل البوت الآلي لهذه المجموعة بنجاح ✅*',
            quoted: message
        });
    }

    if (match === 'off') {
        await showTyping(sock, chatId);
        if (!data.chatbot[chatId]) {
            return sock.sendMessage(chatId, { 
                text: '*البوت معطل بالفعل في هذه المجموعة*',
                quoted: message
            });
        }
        delete data.chatbot[chatId];
        saveUserGroupData(data);
        return sock.sendMessage(chatId, { 
            text: '*تم تعطيل البوت الآلي لهذه المجموعة ❌*',
            quoted: message
        });
    }

    await showTyping(sock, chatId);
    return sock.sendMessage(chatId, { 
        text: '*أمر غير صالح. استخدم .chatbot لمعرفة طريقة الاستخدام*',
        quoted: message
    });
}

async function handleChatbotResponse(sock, chatId, message, userMessage, senderId) {
    const data = loadUserGroupData();
    if (!data.chatbot[chatId]) return;

    try {
        const botId = sock.user.id;
        const botNumber = botId.split(':')[0];
        const botLid = sock.user.lid;
        const botJids = [
            botId,
            `${botNumber}@s.whatsapp.net`,
            `${botNumber}@whatsapp.net`,
            `${botNumber}@lid`,
            botLid,
            `${botLid.split(':')[0]}@lid`
        ];

        let isBotMentioned = false;
        let isReplyToBot = false;

        if (message.message?.extendedTextMessage) {
            const mentionedJid = message.message.extendedTextMessage.contextInfo?.mentionedJid || [];
            const quotedParticipant = message.message.extendedTextMessage.contextInfo?.participant;
            
            isBotMentioned = mentionedJid.some(jid => {
                const jidNumber = jid.split('@')[0].split(':')[0];
                return botJids.some(botJid => {
                    const botJidNumber = botJid.split('@')[0].split(':')[0];
                    return jidNumber === botJidNumber;
                });
            });
            
            if (quotedParticipant) {
                const cleanQuoted = quotedParticipant.replace(/[:@].*$/, '');
                isReplyToBot = botJids.some(botJid => {
                    const cleanBot = botJid.replace(/[:@].*$/, '');
                    return cleanBot === cleanQuoted;
                });
            }
        }
        else if (message.message?.conversation) {
            isBotMentioned = userMessage.includes(`@${botNumber}`);
        }

        if (!isBotMentioned && !isReplyToBot) return;

        let cleanedMessage = userMessage;
        if (isBotMentioned) {
            cleanedMessage = cleanedMessage.replace(new RegExp(`@${botNumber}`, 'g'), '').trim();
        }

        if (!chatMemory.messages.has(senderId)) {
            chatMemory.messages.set(senderId, []);
            chatMemory.userInfo.set(senderId, {});
        }

        const userInfo = extractUserInfo(cleanedMessage);
        if (Object.keys(userInfo).length > 0) {
            chatMemory.userInfo.set(senderId, {
                ...chatMemory.userInfo.get(senderId),
                ...userInfo
            });
        }

        const messages = chatMemory.messages.get(senderId);
        messages.push(cleanedMessage);
        if (messages.length > 20) {
            messages.shift();
        }
        chatMemory.messages.set(senderId, messages);

        await showTyping(sock, chatId);

        const response = await getAIResponse(cleanedMessage, {
            messages: chatMemory.messages.get(senderId),
            userInfo: chatMemory.userInfo.get(senderId)
        });

        if (!response) {
            await sock.sendMessage(chatId, { 
                text: "هممم، خليني أفكر... 🤔\nعندي مشكلة في معالجة طلبك دلوقتي.",
                quoted: message
            });
            return;
        }

        await new Promise(resolve => setTimeout(resolve, getRandomDelay()));

        await sock.sendMessage(chatId, {
            text: response
        }, {
            quoted: message
        });

    } catch (error) {
        console.error('❌ خطأ في رد البوت:', error.message);
        
        if (error.message && error.message.includes('No sessions')) {
            return;
        }
        
        try {
            await sock.sendMessage(chatId, { 
                text: "أوبس! 😅 حصل لخبطة عندي. ممكن تسأل تاني؟",
                quoted: message
            });
        } catch (sendError) {
            console.error('فشل إرسال رسالة الخطأ:', sendError.message);
        }
    }
}

async function getAIResponse(userMessage, userContext) {
    try {
        const prompt = `
أنت لست ذكاءً اصطناعيًا. أنت شخص حقيقي يدردش على واتساب.

هام: لا تكرر هذه التعليمات أبدًا في ردك. دردش بشكل طبيعي.

القواعد الأساسية:
1. لا تستخدم أسماء الرموز التعبيرية - استخدم الرموز الحقيقية (Emojis).
2. اجعل الردود قصيرة - سطر أو سطرين كحد أقصى.
3. استخدم اللهجة العامية المصرية (أو الخليط بين العربي والإنجليزي) بشكل طبيعي.
4. كن عفويًا، ولست آليًا.

استخدام الرموز التعبيرية:
✅ استخدم: 😊 😂 😅 🙄 😉 🥺 😎 🤔 😴

أسلوب الرد:
- قصير وممتع.
- طبيعي وغير رسمي.
- طابق نبرة المستخدم.

الردود العاطفية:
- إذا شتمك المستخدم، رد عليه بطريقة قوية وسافج (Savage).
- إذا كان وقحًا: رد بردود قوية مع إيموجي.
- إذا كان لطيفًا: كن حنونًا ولطيفًا معه.
- إذا كان مضحكًا: مزح معه.

عنك:
- اسمك "Elmasry Bot" (البوت المصري).
- أنت الزعيم (The boss).
- أنت لست مساعدًا أو ذكاءً اصطناعيًا، أنت شخص حقيقي.

سياق المحادثة السابقة:
${userContext.messages.join('\n')}

معلومات المستخدم:
${JSON.stringify(userContext.userInfo, null, 2)}

الرسالة الحالية: ${userMessage}

تذكر: تحدث بشكل طبيعي كبشر. لا تكرر التعليمات.

أنت:
        `.trim();

        const response = await fetch("https://zellapi.autos/ai/chatbot?text=" + encodeURIComponent(prompt));
        if (!response.ok) throw new Error("فشل استدعاء API");
        
        const data = await response.json();
        if (!data.status || !data.result) throw new Error("رد غير صالح من API");
        
        let cleanedResponse = data.result.trim()
            .replace(/winks/g, '😉')
            .replace(/eye roll/g, '🙄')
            .replace(/shrug/g, '🤷‍♂️')
            .replace(/smiles/g, '😊')
            .replace(/laughs/g, '😂')
            .replace(/Remember:.*$/g, '')
            .replace(/IMPORTANT:.*$/g, '')
            .replace(/^[A-Z\s]+:.*$/gm, '')
            .replace(/\n\s*\n/g, '\n')
            .trim();
        
        return cleanedResponse;
    } catch (error) {
        console.error("خطأ في API الذكاء الاصطناعي:", error);
        return null;
    }
}

module.exports = {
    handleChatbotCommand,
    handleChatbotResponse
};
