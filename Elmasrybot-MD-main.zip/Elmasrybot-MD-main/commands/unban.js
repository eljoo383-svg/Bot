const fs = require('fs');
const path = require('path');
const { channelInfo } = require('../lib/messageConfig');
const isAdmin = require('../lib/isAdmin');
const { isSudo } = require('../lib/index');

async function unbanCommand(sock, chatId, message) {
    // التحقق من الصلاحيات (في المجموعات أو الخاص)
    const isGroup = chatId.endsWith('@g.us');
    if (isGroup) {
        const senderId = message.key.participant || message.key.remoteJid;
        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);
        
        if (!isBotAdmin) {
            await sock.sendMessage(chatId, { 
                text: '⚠️ *تـنـبـيـه إداري* ⚠️\n\nيـرجى رفـع الـبوت لـرتبـة *أدمـن* أولاً لـتفعيل خاصية فك الحظر! ⚙️💎', 
                ...channelInfo 
            }, { quoted: message });
            return;
        }
        
        if (!isSenderAdmin && !message.key.fromMe) {
            await sock.sendMessage(chatId, { 
                text: '🚫 *تـصـريـح مـرفـوض* 🚫\n\nعـذراً يـا وحـش، صـلاحـيـة فـك الـحـظـر لـلأساطـير (الأدمـن) فـقـط! 👑', 
                ...channelInfo 
            }, { quoted: message });
            return;
        }
    } else {
        const senderId = message.key.participant || message.key.remoteJid;
        const senderIsSudo = await isSudo(senderId);
        if (!message.key.fromMe && !senderIsSudo) {
            await sock.sendMessage(chatId, { 
                text: '🔒 *خـاص بـالـمـطـور* 🔒\n\nفـك الـحـظر فـي الـخـاص مـتـاح فـقـط لـمـطـور الـبوت الـعظـيم! 💎✨', 
                ...channelInfo 
            }, { quoted: message });
            return;
        }
    }

    let userToUnban;
    
    // التحقق من المنشن
    if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        userToUnban = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
    }
    // التحقق من الرد (Reply)
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToUnban = message.message.extendedTextMessage.contextInfo.participant;
    }
    
    if (!userToUnban) {
        await sock.sendMessage(chatId, { 
            text: '❓ *تـعـلـيـمـات الـ VIP* ❓\n\nيـرجى عـمـل مـنـشن (@) لـلـمـسـتخدم أو الـرد عـلى رسـالـتـه لـفـك الـحـظر عـنـه! 🔓✨', 
            ...channelInfo 
        }, { quoted: message });
        return;
    }

    try {
        const bannedUsers = JSON.parse(fs.readFileSync('./data/banned.json'));
        const index = bannedUsers.indexOf(userToUnban);
        
        if (index > -1) {
            bannedUsers.splice(index, 1);
            fs.writeFileSync('./data/banned.json', JSON.stringify(bannedUsers, null, 2));
            
            // ✅ رسالة فك الحظر بنجاح
            await sock.sendMessage(chatId, { 
                text: `🔓 *عـفـو مـلـكـي حـصـري* 🔓\n` +
                      `━━━━━━━━━━━━━━━━━━━━\n\n` +
                      `✨ تـم فـك الـحـظـر عـن الـمـسـتـخـدم:\n` +
                      `👤 @${userToUnban.split('@')[0]}\n\n` +
                      `✅ يـمـكـنـه الآن اسـتـخدام الـبوت بـحـريـة!\n\n` +
                      `━━━━━━━━━━━━━━━━━━━━\n` +
                      `💎 *VIP BOT | نـنـصـف الـجـمـيـع* 💎`,
                mentions: [userToUnban],
                ...channelInfo 
            });
        } else {
            // ℹ️ حالة لو المستخدم مش محظور أصلاً
            await sock.sendMessage(chatId, { 
                text: `💡 *تـنـبـيـه* 💡\n\nالـمـسـتخدم @${userToUnban.split('@')[0]} لـيـس مـحـظـوراً فـي قـوائـمـنـا بـالأسـاس! 🛡️✨`,
                mentions: [userToUnban],
                ...channelInfo 
            });
        }
    } catch (error) {
        console.error('Error in unban command:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ *فـشـلـت الـعـمـلـيـة* ❌\n\nحـدث خـطأ تـقـني أثـنـاء مـحـاولة فـك الـحـظر! 🛠️🌀', 
            ...channelInfo 
        }, { quoted: message });
    }
}

module.exports = unbanCommand;
