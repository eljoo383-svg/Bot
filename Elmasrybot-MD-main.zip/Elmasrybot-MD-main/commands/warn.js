const fs = require('fs');
const path = require('path');
const isAdmin = require('../lib/isAdmin');

// إعداد المسارات
const databaseDir = path.join(process.cwd(), 'data');
const warningsPath = path.join(databaseDir, 'warnings.json');

// تهيئة ملف التحذيرات
function initializeWarningsFile() {
    if (!fs.existsSync(databaseDir)) {
        fs.mkdirSync(databaseDir, { recursive: true });
    }
    if (!fs.existsSync(warningsPath)) {
        fs.writeFileSync(warningsPath, JSON.stringify({}), 'utf8');
    }
}

async function warnCommand(sock, chatId, senderId, mentionedJids, message) {
    try {
        initializeWarningsFile();

        // التحقق من أن الأمر في مجموعة
        if (!chatId.endsWith('@g.us')) {
            await sock.sendMessage(chatId, { 
                text: '❌ *عـذراً يا وحـش*.. هـذا الأمـر مـتـاح فـقـط داخـل الـمـجـموعـات! 🛡️'
            });
            return;
        }

        try {
            const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);
            
            if (!isBotAdmin) {
                await sock.sendMessage(chatId, { 
                    text: '⚠️ *تـنـبـيـه إداري* ⚠️\n\nيـرجى رفـع الـبـوت لـرتبـة *أدمـن* أولاً لـتـفـعـيـل نـظـام الـتـحـذيـرات! ⚙️💎'
                });
                return;
            }

            if (!isSenderAdmin) {
                await sock.sendMessage(chatId, { 
                    text: '🚫 *تـصـريـح مـرفـوض* 🚫\n\nعـذراً، هـذا الأمـر مـخـصـص فـقـط لـ *أساطـيـر الإدارة*! 👑✨'
                });
                return;
            }
        } catch (adminError) {
            await sock.sendMessage(chatId, { 
                text: '❌ *خـطأ فـني*.. تـأكـد مـن صـلاحـيـات الـبـوت وحـاول مـرة أخـرى! 🛠️'
            });
            return;
        }

        let userToWarn;
        if (mentionedJids && mentionedJids.length > 0) {
            userToWarn = mentionedJids[0];
        } else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
            userToWarn = message.message.extendedTextMessage.contextInfo.participant;
        }
        
        if (!userToWarn) {
            await sock.sendMessage(chatId, { 
                text: '❓ *تـعـلـيـمات الـ VIP* ❓\n\nيـرجى مـنـشـنـة الـمـسـتخدم أو الـرد عـلى رسـالـتـه لـتـوجـيـه الـتـحـذيـر! ⚠️💎'
            });
            return;
        }

        await new Promise(resolve => setTimeout(resolve, 1000));

        try {
            let warnings = {};
            try {
                warnings = JSON.parse(fs.readFileSync(warningsPath, 'utf8'));
            } catch (error) {
                warnings = {};
            }

            if (!warnings[chatId]) warnings[chatId] = {};
            if (!warnings[chatId][userToWarn]) warnings[chatId][userToWarn] = 0;
            
            warnings[chatId][userToWarn]++;
            fs.writeFileSync(warningsPath, JSON.stringify(warnings, null, 2));

            // ⚠️ رسالة التحذير الـ VIP
            const warningMessage = `⚠️ *تـنـبـيـه إداري عـاجـل* ⚠️\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `👤 *الـمُـحـذر:* @${userToWarn.split('@')[0]}\n` +
                `📉 *عـدد الـتـحـذيـرات:* ${warnings[chatId][userToWarn]} مـن 3\n` +
                `👮 *بـواسـطـة:* @${senderId.split('@')[0]}\n\n` +
                `📅 *الـتـاريـخ:* ${new Date().toLocaleString()}\n\n` +
                `🛡️ _الـتـزم بـالـقوانـين لـتـجـنـب الـطرد الـتـلـقائـي!_ \n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `✨ *VIP BOT SYSTEM* ✨`;

            await sock.sendMessage(chatId, { 
                text: warningMessage,
                mentions: [userToWarn, senderId]
            });

            // 🚫 الطرد التلقائي عند الوصول لـ 3 تحذيرات
            if (warnings[chatId][userToWarn] >= 3) {
                await new Promise(resolve => setTimeout(resolve, 1000));

                await sock.groupParticipantsUpdate(chatId, [userToWarn], "remove");
                delete warnings[chatId][userToWarn];
                fs.writeFileSync(warningsPath, JSON.stringify(warnings, null, 2));
                
                const kickMessage = `🚫 *تـم الـتـنـفـيـذ الـقـانـونـي* 🚫\n\n` +
                    `تـم طـرد @${userToWarn.split('@')[0]} تـلـقـائـيـاً لـتـجـاوز عـدد الـتـحـذيـرات الـمـسـمـوح بـه (3/3)! 🚷🔥`;

                await sock.sendMessage(chatId, { 
                    text: kickMessage,
                    mentions: [userToWarn]
                });
            }
        } catch (error) {
            await sock.sendMessage(chatId, { text: '❌ *فـشل تـسجـيل الـتحـذير!* 🛠️' });
        }
    } catch (error) {
        if (error.data === 429) {
            await sock.sendMessage(chatId, { text: '⏳ *ضـغط عـالـي*.. جـرب بـعـد ثـوانـي يـا وحـش! ⚡' });
        } else {
            await sock.sendMessage(chatId, { text: '❌ *فـشل فـي الـتـعامل مـع الـمـستخدم*.. تـأكـد مـن رتـبة الـبـوت! 🛡️' });
        }
    }
}

module.exports = warnCommand;
