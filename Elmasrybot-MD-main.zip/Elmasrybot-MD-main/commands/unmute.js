async function unmuteCommand(sock, chatId) {
    await sock.groupSettingUpdate(chatId, 'not_announcement'); // Unmute the group
    await sock.sendMessage(chatId, { text: 'تم الغاء كتم المجتمعه 🔓.' });
}

module.exports = unmuteCommand;
