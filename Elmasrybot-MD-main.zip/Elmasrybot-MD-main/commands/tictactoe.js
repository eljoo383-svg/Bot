const TicTacToe = require('../lib/tictactoe');

// تخزين الألعاب بشكل عام
const games = {};

async function tictactoeCommand(sock, chatId, senderId, text) {
    try {
        // التحقق مما إذا كان اللاعب في مباراة بالفعل
        if (Object.values(games).find(room => 
            room.id.startsWith('tictactoe') && 
            [room.game.playerX, room.game.playerO].includes(senderId)
        )) {
            await sock.sendMessage(chatId, { 
                text: '❌ أنت بالفعل في مباراة جارية. اكتب *انسحاب* للمغادرة.' 
            });
            return;
        }

        // البحث عن غرفة بانتظار لاعب آخر
        let room = Object.values(games).find(room => 
            room.state === 'WAITING' && 
            (text ? room.name === text : true)
        );

        if (room) {
            // الانضمام لغرفة موجودة
            room.o = chatId;
            room.game.playerO = senderId;
            room.state = 'PLAYING';

            const arr = room.game.render().map(v => ({
                'X': '❎',
                'O': '⭕',
                '1': '1️⃣',
                '2': '2️⃣',
                '3': '3️⃣',
                '4': '4️⃣',
                '5': '5️⃣',
                '6': '6️⃣',
                '7': '7️⃣',
                '8': '8️⃣',
                '9': '9️⃣',
            }[v]));

            const str = `
🎮 *بدأت مباراة إكس أو (TicTacToe)!*

انتظار @${room.game.currentTurn.split('@')[0]} للعب...

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

▢ *معرف الغرفة:* ${room.id}
▢ *القوانين:*
• كون صفاً من 3 رموز (رأسياً أو أفقياً أو قطرياً) للفوز.
• اكتب رقماً من (1-9) لوضع رمزك في المكان المحدد.
• اكتب *انسحاب* للاستسلام.
`;

            await sock.sendMessage(chatId, { 
                text: str,
                mentions: [room.game.currentTurn, room.game.playerX, room.game.playerO]
            });

        } else {
            // إنشاء غرفة جديدة
            room = {
                id: 'tictactoe-' + (+new Date),
                x: chatId,
                o: '',
                game: new TicTacToe(senderId, 'o'),
                state: 'WAITING'
            };

            if (text) room.name = text;

            await sock.sendMessage(chatId, { 
                text: `⏳ *بانتظار المنافس...*\nاكتب *.ttt ${text || ''}* للانضمام واللعب ضد @${senderId.split('@')[0]}!`,
                mentions: [senderId]
            });

            games[room.id] = room;
        }

    } catch (error) {
        console.error('Error in tictactoe command:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ حدث خطأ أثناء بدء اللعبة. حاول مرة أخرى.' 
        });
    }
}

async function handleTicTacToeMove(sock, chatId, senderId, text) {
    try {
        // البحث عن مباراة اللاعب الحالية
        const room = Object.values(games).find(room => 
            room.id.startsWith('tictactoe') && 
            [room.game.playerX, room.game.playerO].includes(senderId) && 
            room.state === 'PLAYING'
        );

        if (!room) return;

        // دعم كلمتي surrender بالإنجليزية و "انسحاب" بالعربية
        const isSurrender = /^(surrender|give up|انسحاب|استسلام)$/i.test(text);
        
        if (!isSurrender && !/^[1-9]$/.test(text)) return;

        // السماح بالانسحاب في أي وقت، أما اللعب فيكون في الدور فقط
        if (senderId !== room.game.currentTurn && !isSurrender) {
            await sock.sendMessage(chatId, { 
                text: '❌ ليس دورك الآن!' 
            });
            return;
        }

        let ok = isSurrender ? true : room.game.turn(
            senderId === room.game.playerO,
            parseInt(text) - 1
        );

        if (!ok) {
            await sock.sendMessage(chatId, { 
                text: '❌ حركة غير صالحة! هذا المربع ممتلئ بالفعل.' 
            });
            return;
        }

        let winner = room.game.winner;
        let isTie = room.game.turns === 9;

        const arr = room.game.render().map(v => ({
            'X': '❎',
            'O': '⭕',
            '1': '1️⃣',
            '2': '2️⃣',
            '3': '3️⃣',
            '4': '4️⃣',
            '5': '5️⃣',
            '6': '6️⃣',
            '7': '7️⃣',
            '8': '8️⃣',
            '9': '9️⃣',
        }[v]));

        if (isSurrender) {
            winner = senderId === room.game.playerX ? room.game.playerO : room.game.playerX;
            
            await sock.sendMessage(chatId, { 
                text: `🏳️ لقد انسحب @${senderId.split('@')[0]}! الفائز هو @${winner.split('@')[0]} 🏆`,
                mentions: [senderId, winner]
            });
            
            delete games[room.id];
            return;
        }

        let gameStatus;
        if (winner) {
            gameStatus = `🎉 تهانينا! @${winner.split('@')[0]} هو الفائز! 🏆`;
        } else if (isTie) {
            gameStatus = `🤝 انتهت المباراة بالتعادل!`;
        } else {
            gameStatus = `🎲 الدور الآن على: @${room.game.currentTurn.split('@')[0]} (${room.game.currentTurn === room.game.playerX ? '❎' : '⭕'})`;
        }

        const str = `
🎮 *مباراة إكس أو (TicTacToe)*

${gameStatus}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

▢ اللاعب ❎: @${room.game.playerX.split('@')[0]}
▢ اللاعب ⭕: @${room.game.playerO.split('@')[0]}

${!winner && !isTie ? '• اكتب رقماً (1-9) للعب\n• اكتب *انسحاب* للاستسلام' : ''}
`;

        const mentions = [
            room.game.playerX, 
            room.game.playerO,
            ...(winner ? [winner] : [room.game.currentTurn])
        ];

        await sock.sendMessage(room.x, { 
            text: str,
            mentions: mentions
        });

        if (room.x !== room.o) {
            await sock.sendMessage(room.o, { 
                text: str,
                mentions: mentions
            });
        }

        if (winner || isTie) {
            delete games[room.id];
        }

    } catch (error) {
        console.error('Error in tictactoe move:', error);
    }
}

module.exports = {
    tictactoeCommand,
    handleTicTacToeMove
};
