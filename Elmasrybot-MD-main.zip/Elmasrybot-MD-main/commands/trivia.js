const axios = require('axios');

let triviaGames = {};

async function startTrivia(sock, chatId) {
    if (triviaGames[chatId]) {
        sock.sendMessage(chatId, { text: '⏳ هناك سؤال جاري بالفعل في هذا الشات!' });
        return;
    }

    try {
        const response = await axios.get('https://opentdb.com/api.php?amount=1&type=multiple');
        const questionData = response.data.results[0];

        triviaGames[chatId] = {
            question: questionData.question,
            correctAnswer: questionData.correct_answer,
            options: [...questionData.incorrect_answers, questionData.correct_answer].sort(),
        };

        sock.sendMessage(chatId, {
            text: `❓ *وقت المسابقة!*\n\nالسؤال: ${triviaGames[chatId].question}\n\nالخيارات المتاحة:\n${triviaGames[chatId].options.join('\n')}\n\nأجب بكتابة الإجابة الصحيحة.`
        });
    } catch (error) {
        sock.sendMessage(chatId, { text: '❌ فشل جلب السؤال. حاول مرة أخرى لاحقاً.' });
    }
}

function answerTrivia(sock, chatId, answer) {
    if (!triviaGames[chatId]) {
        sock.sendMessage(chatId, { text: '❌ لا توجد مسابقة جارية حالياً.' });
        return;
    }

    const game = triviaGames[chatId];

    if (answer.toLowerCase() === game.correctAnswer.toLowerCase()) {
        sock.sendMessage(chatId, { text: `✅ إجابة صحيحة! برافو عليك.` });
    } else {
        sock.sendMessage(chatId, { text: `❌ إجابة خاطئة! الإجابة الصحيحة كانت: ${game.correctAnswer}` });
    }

    delete triviaGames[chatId];
}

module.exports = { startTrivia, answerTrivia };
