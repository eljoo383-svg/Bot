const isAdmin = require('../lib/isAdmin');

// دالة لمعالجة أوامر الترقية اليدوية عبر الأوامر
async function promoteCommand(sock, chatId, mentionedJids, message) {
    let userToPromote = [];
    
    // التحقق من المستخدمين المشار إليهم (التاق)
    if (mentionedJids && mentionedJids.length > 0) {
        userToPromote = mentionedJids;
    }
    // التحقق من الرد على رسالة مستخدم
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToPromote = [message.message.extendedTextMessage.contextInfo.participant];
    }
    
    // إذا لم يتم العثور على مستخدم
    if (userToPromote.length === 0) {
        await sock.sendMessage(chatId, { 
            text: 'يرجى الإشارة (تاق) للعضو أو الرد على رسالته لترقيته لمشرف!'
        });
        return;
    }

    try {
        await sock.groupParticipantsUpdate(chatId, userToPromote, "promote");
        
        const usernames = await Promise.all(userToPromote.map(async jid => {
            return `@${jid.split('@')[0]}`;
        }));

        const promoterJid = sock.user.id;
        
        const promotionMessage = `*『 ترقية عضو لمشرف 』*\n\n` +
            `👥 *المشرفين الجدد:* \n` +
            `${usernames.map(name => `• ${name}`).join('\n')}\n\n` +
            `👑 *بواسطة:* @${promoterJid.split('@')[0]}\n\n` +
            `📅 *التاريخ:* ${new Date().toLocaleString('ar-EG')}`;

        await sock.sendMessage(chatId, { 
            text: promotionMessage,
            mentions: [...userToPromote, promoterJid]
        });
    } catch (error) {
        console.error('Error in promote command:', error);
        await sock.sendMessage(chatId, { text: 'فشل ترقية العضو، تأكد من صلاحيات البوت!'});
    }
}

// دالة لمعالجة اكتشاف الترقية التلقائية (عندما يرفع مشرف عضو آخر)
async function handlePromotionEvent(sock, groupId, participants, author) {
    try {
        if (!Array.isArray(participants) || participants.length === 0) {
            return;
        }

        const promotedUsernames = await Promise.all(participants.map(async jid => {
            const jidString = typeof jid === 'string' ? jid : (jid.id || jid.toString());
            return `@${jidString.split('@')[0]} `;
        }));

        let promotedBy;
        let mentionList = participants.map(jid => {
            return typeof jid === 'string' ? jid : (jid.id || jid.toString());
        });

        if (author && author.length > 0) {
            const authorJid = typeof author === 'string' ? author : (author.id || author.toString());
            promotedBy = `@${authorJid.split('@')[0]}`;
            mentionList.push(authorJid);
        } else {
            promotedBy = 'النظام';
        }

        const promotionMessage = `*『 تنبيه ترقية جديدة 』*\n\n` +
            `👥 *العضو الذي تمت ترقيته:* \n` +
            `${promotedUsernames.map(name => `• ${name}`).join('\n')}\n\n` +
            `👑 *بواسطة:* ${promotedBy}\n\n` +
            `📅 *التاريخ:* ${new Date().toLocaleString('ar-EG')}`;
        
        await sock.sendMessage(groupId, {
            text: promotionMessage,
            mentions: mentionList
        });
    } catch (error) {
        console.error('Error handling promotion event:', error);
    }
}

module.exports = { promoteCommand, handlePromotionEvent };
