const fetch = require('node-fetch');

module.exports = async function quoteCommand(sock, chatId, message) {
    try {
        // قائمة حكم وأمثال مصرية "في الجون"
        const quotes = [
            "لو كلك عيوب.. متصلحش غير عيونك اللي بتشوف بيها عيوب الناس.",
            "اللي يمشي ورا كلام الناس.. يغرق في شبر مية.",
            "صاحب صاحبه مش اللي يضحك في وشك، صاحب صاحبه اللي يسندك في وقت ضيقتك.",
            "ما تفتخرش بجمالك عشان مش انت اللي صنعته، افتخر بأخلاقك عشان انت اللي بتعملها.",
            "المركب اللي ليها رئيسين تغرق.. والقلب اللي فيه حبيبين يتدمر.",
            "يا بخت من بكاني وبكى عليا، ولا ضحكني وضحك الناس عليا.",
            "اللي باعك بالفول.. بيعه بقشره.",
            "ما تعملش قيمة للي معندوش أصل، عشان لو شبع هيشوف نفسه عليك.",
            "الرجولة أفعال.. مش شوية كلام على الواتساب.",
            "امشي عدل يحتار عدوك فيك."
        ];

        // اختيار حكمة عشوائية
        const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];

        const finalMessage = `📜 *حكمة اليوم:*\n\n"${randomQuote}"\n\n*Elmasry Bot 🤖*`;

        await sock.sendMessage(chatId, { text: finalMessage }, { quoted: message });

    } catch (error) {
        console.error('Error in quote command:', error);
        await sock.sendMessage(chatId, { text: '❌ حصل مشكلة وأنا بجيب الحكمة، خليك حكيم وجرب تاني!' }, { quoted: message });
    }
};
