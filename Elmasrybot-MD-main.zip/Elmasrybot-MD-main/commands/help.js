const settings = require('../settings');
const fs = require('fs');
const path = require('path');

async function helpCommand(sock, chatId, message) {
    const helpMessage = `
╔═══════════════════╗
✨🤖 *ELMASRY BOT* ✨
│📦 Issue: *3.0.0*  
│ 👑 by: *المطور المصري*
│📺 YT: ${global.ytch} 
╚═══════════════════╝
🌟══════════🌟
 *✨الأوامر المتاحة✨*  
🌟══════════🌟
╔═══════════════════╗
🌐 *الأوامر العامة*:
║ ⚡ .help — عرض القايمة
║ 📜 .menu — نفس الكلام
║ 🏎️ .ping — سرعة البوت
║ 🌙 .alive — البوت صاحي ولا نايم
║ 🔊 .tts <text> — تحويل النص لصوت
║ 👤 .owner — معلومات صاحب البوت
║ 😂 .joke — نكتة
║ 💡 .quote — حكمة
║ 🌍 .fact — حقيقة غريبة
║ ☀️🌧️ .weather <city> — حالة الجو
║ 📰 .news — آخر الأخبار
║ ✨ .attp <text> — استيكر متحرك
║ 🎶 .lyrics <song> — كلمات أغنية
║ 🎱 .8ball <question> — كرة سحرية
║ 🏘️ .groupinfo — معلومات الجروب
║ 👑 .admins — المشرفين
║ 🖼️ .vv — تحميل صورة مخفية
║ 🌐 .trt <text> <lang> — ترجمة
║ 📸 .ss <link> — سكرين شوت
║ 🆔 .jid — جلب ID
║ 🔗 .url — رفع الصورة لرابط
╚═══════════════════╝
╔═══════════════════╗
👮‍♂️ *أوامر المسؤول*:
║ ⛔ .ban @user — حظر وطرد
║ 🛡️ .promote @user — ترقية
║ 🗑️ .demote @user — تنزيل
║ 🔇 .mute <min> — اسكات مؤقت
║ 🔊 .unmute — فك الاسكات
║ 🗑️ .delete — حذف رسالة
║ 👢 .kick @user — طرد
║ ⚠️ .warnings @user — إنذارات
║ ⚠️ .warn @user — تحذير
║ 🔗❌ .antilink — منع الروابط
║ 💬❌ .antibadword — منع الشتائم
║ 🧹 .clear — تنظيف الشات
║ 📣 .tag <msg> — منشن جماعي
║ 🔔 .tagall — منشن للكل
║ 👻 .hidetag <msg> — منشن مخفي
║ 🤖 .chatbot — تفعيل الذكاء الاصطناعي
║ 🔄 .resetlink — إعادة رابط الجروب
║ 🚫 .antitag <on/off> — منع المنشن
║ 🎉 .welcome <on/off> — الترحيب
║ 👋 .goodbye <on/off> — الوداع
║ ✏️ .setgdesc — تغيير وصف الجروب
║ 🏷️ .setgname — تغيير اسم الجروب
║ 🖼️ .setgpp — تغيير صورة الجروب
╚═══════════════════╝
╔═══════════════════╗
🔒 *أوامر المالك*:
║ ⚙️ .mode <public/private>
║ 🧹 .clearsession
║ 🚫 .antidelete
║ 🧹 .cleartmp
║ 🔄 .update
║ ⚙️ .settings
║ 🖼️ .setpp <reply to image>
║ ✨ .autoreact <on/off>
║ 🔄 .autostatus <on/off>
║ ✨ .autostatus react <on/off>
║ ⌨️ .autotyping <on/off>
║ 📖 .autoread <on/off>
║ 📵 .anticall <on/off>
║ 🚫 .pmblocker <on/off/status>
║ ✏️ .pmblocker setmsg <text>
║ 🏷️ .setmention <reply to msg>
║ ✨ .mention <on/off>
╚════════════════════╝
╔════════════════════╗
🎨 *أوامر الصور والملصقات*:
║ 🌫️ .blur — تشويش
║ 🖼️ .simage — تحويل استيكر لصورة
║ 🏷️ .sticker — تحويل صورة لاستيكر
║ ❌ .removebg — إزالة الخلفية
║ ✂️ .crop — قص الصورة
║ ✨ .attp — كتابة متحركة
║ 🖊️ .ttp — كتابة على استيكر
║ 🖼️ .toimage — تحويل استيكر لصورة
║ 🎞️ .togif — تحويل استيكر GIF
║ 🔗 .urltoimg — صورة من لينك
║ 🔄 .convert — تحويل الصيغ
║ 🔵 .circle — دائرة
║ ⚡ .triggered — تأثير عصبية
╚════════════════════╝
╔════════════════════╗
🖼️ *أوامر الفطائر*:
║ 🥧 .pies <country>
║ 🇨🇳 .china 
║ 🇮🇩 .indonesia 
║ 🇯🇵 .japan 
║ 🇰🇷 .korea 
║ 🧕 .hijab
╚════════════════════╝
╔════════════════════╗
🎮 *الألعاب*:
║ ❌⭕ .tictactoe — XO
║ 🤷 .hangman — الرجل المشنوق
║ ❓ .guess — خمن حرف
║ ❔ .trivia — سؤال عام
║ ✔️ .answer — إجابة
║ 🕵️ .truth — حقيقة
║ 😈 .dare — جرأة
╚════════════════════╝
╔════════════════════╗
🤖 *ذكاء اصطناعي*:
║ 🧠 .gpt — اسأل شات جي بي تي
║ 🌌 .gemini — اسأل جيميناي
║ 🎨 .imagine — توليد صور
║ 🎬 .flux — صنع صور وفيديوهات
║ 🎥 .sora — صنع فيديوهات
╚════════════════════╝
╔════════════════════╗
🎯 *أوامر ممتعة*:
║ 💖 .compliment @user — مدح
║ 😡 .insult @user — سب
║ 😘 .flirt — غزل
║ 📝 .shayari — شعر
║ 🌙 .goodnight — تصبح على خير
║ 🌹 .roseday — صورة
║ 🕵️‍♂️ .character @user — تحليل
║ 🎮 .wasted @user — صورة GTA
║ 💞 .ship @user — نسبة حب
║ 😅 .simp @user — تعليق
║ 🤪 .stupid @user [text] — ميم
╚════════════════════╝
╔════════════════════╗
🔤 *صانع النصوص*:
║ ⚡ .metallic — نص معدني
║ ❄️ .ice — نص ثلجي
║ ⛄ .snow — تأثير ثلج
║ ✨ .impressive — نص لامع
║ 🟩 .matrix — نص أخضر
║ 💡 .light — نص مضيء
║ 🌟 .neon — نص نيون
║ 😈 .devil — نص أحمر
║ 🟪 .purple — نص بنفسجي
║ ⚡ .thunder — نص بريق
║ 🍃 .leaves — نص نبات
║ 🛡️ .1917 — نص حربي
║ ⚔️ .arena — .نص قتالي
║ 💻 .hacker — نص هكر
║ 🏜️ .sand — نص رملي
║ 🎀 .blackpink — نص فرقة
║ 🌀 .glitch — نص مشوه
║ 🔥 .fire — نص ناري
╚═══════════════════╝
╔═══════════════════╗
🎵 *أوامر الموسيقى والفيديو*:
║ 🎶 .play <song> — تشغيل أغنية
║ 📹 .ytmp4 <link> — تحميل فيديو
║ 🎧 .ytmp3 <link> — تحميل MP3
║ 📘 .fb <link> — تحميل فيسبوك
║ 🎵 .tiktok <link> — تحميل تيك توك
║ 📸 .instagram <link> — تحميل انستجرام
║ 🔍 .video <query> — بحث فيديو
║ 🔍 .audio <query> — بحث صوت
╚═══════════════════╝
╔═══════════════════╗
🧩 *متفرقات*:
║ ❤️ .heart — صورك في قلب
║ 😏 .horny — صورة لملصق
║ 🔵 .circle — صورتك دائرة 
║ 🏳️‍🌈 .lgbt — يعمل فريم علم
║ 😂 .lolice — ميم مشهور
║ 🤪 .its-so-stupid — ميمز جاهز
║ 🃏 .namecard — كارت تعريف
║ 🐢 .oogway — ميمز جاهز
║ 🐦 .tweet — صورة تويتر
║ 💬 .ytcomment — يوتيوب فيك 
║ ✊ .comrade — ميمز جاهز
║ 🏳️‍🌈 .gay — علم مثليين 
║ 💥 .glass — تكسير زجاج
║ 🚔 .jail — سجن
║ ✅ .passed — ميم جاهز
║ ⚡ .triggered — يعمل GIF
╚═══════════════════╝
╔═══════════════════╗
🖼️ *أنيمي*:
║ 😢 .nom 
║ 👋 .poke 
║ 😭 .cry 
║ 😘 .kiss 
║ 🤗 .pat 
║ 😉 .wink 
║ 🤦‍♂️ .facepalm 
╚═══════════════════╝
╔═══════════════════╗
💻 *أوامر جيثب*:
║ 🔗 .git
║ 🔗 .github
║ 💻 .sc
║ 📝 .script
║ 📦 .repo
╚═══════════════════╝
╔═══════════════════╗
 💖 *حقوق البوت:*
 ELMASRY © 2026
╚═══════════════════╝

Join our channel for updates:`;

    try {
        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');
        
        if (fs.existsSync(imagePath)) {
            const imageBuffer = fs.readFileSync(imagePath);
            
            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363405610374694@newsletter',
                        newsletterName: 'BOT ELMASRY MD',
                        serverMessageId: -1
                    }
                }
            },{ quoted: message });
        } else {
            console.error('Bot image not found at:', imagePath);
            await sock.sendMessage(chatId, { 
                text: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363405610374694@newsletter',
                        newsletterName: 'BOT ELMASRY MD by Mr Omar Hacker',
                        serverMessageId: -1
                    } 
                }
            });
        }
    } catch (error) {
        console.error('Error in help command:', error);
        await sock.sendMessage(chatId, { text: helpMessage });
    }
}

module.exports = helpCommand;