const isAdmin = require('../lib/isAdmin');

// دالة لمعالجة أوامر تنزيل الرتبة يدوياً عبر الأوامر
async function demoteCommand(sock, chatId, mentionedJids, message) {
    try {
        // التحقق مما إذا كانت الدردشة مجموعة
        if (!chatId.endsWith('@g.us')) {
            await sock.sendMessage(chatId, { 
                text: 'يمكن استخدام هذا الأمر داخل المجموعات فقط!'
            });
            return;
        }

        // التحقق من صلاحيات المشرفين والبوت
        try {
            const adminStatus = await isAdmin(sock, chatId, message.key.participant || message.key.remoteJid);
            
            if (!adminStatus.isBotAdmin) {
                await sock.sendMessage(chatId, { 
                    text: '❌ خطأ: يرجى رفع البوت إلى مشرف أولاً لاستخدام هذا الأمر.'
                });
                return;
            }

            if (!adminStatus.isSenderAdmin) {
                await sock.sendMessage(chatId, { 
                    text: '❌ خطأ: هذا الأمر مخصص لمشرفي المجموعة فقط.'
                });
                return;
            }
        } catch (adminError) {
            console.error('Error checking admin status:', adminError);
            await sock.sendMessage(chatId, { 
                text: '❌ خطأ: تأكد من أن البوت مشرف في هذه المجموعة.'
            });
            return;
        }

        let userToDemote = [];
        
        // التحقق من الإشارة للعضو (تاق)
        if (mentionedJids && mentionedJids.length > 0) {
            userToDemote = mentionedJids;
        }
        // التحقق من الرد على رسالة عضو
        else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
            userToDemote = [message.message.extendedTextMessage.contextInfo.participant];
        }
        
        // إذا لم يتم تحديد مستخدم
        if (userToDemote.length === 0) {
            await sock.sendMessage(chatId, { 
                text: '❌ خطأ: يرجى الإشارة للعضو أو الرد على رسالته لتنزيل رتبته!'
            });
            return;
        }

        await new Promise(resolve => setTimeout(resolve, 1000));

        await sock.groupParticipantsUpdate(chatId, userToDemote, "demote");
        
        const usernames = await Promise.all(userToDemote.map(async jid => {
            return `@${jid.split('@')[0]}`;
        }));

        await new Promise(resolve => setTimeout(resolve, 1000));

        const demotionMessage = `*『 تنزيل رتبة مشرف 』*\n\n` +
            `👤 *العضو المنزّل:* \n` +
            `${usernames.map(name => `• ${name}`).join('\n')}\n\n` +
            `👑 *بواسطة:* @${message.key.participant ? message.key.participant.split('@')[0] : message.key.remoteJid.split('@')[0]}\n\n` +
            `📅 *التاريخ:* ${new Date().toLocaleString('ar-EG')}`;
        
        await sock.sendMessage(chatId, { 
            text: demotionMessage,
            mentions: [...userToDemote, message.key.participant || message.key.remoteJid]
        });
    } catch (error) {
        console.error('Error in demote command:', error);
        if (error.data === 429) {
            await new Promise(resolve => setTimeout(resolve, 2000));
            try {
                await sock.sendMessage(chatId, { 
                    text: '❌ تم الوصول للحد الأقصى للطلبات. يرجى المحاولة بعد ثوانٍ.'
                });
            } catch (retryError) {
                console.error('Error sending retry message:', retryError);
            }
        } else {
            try {
                await sock.sendMessage(chatId, { 
                    text: '❌ فشل تنزيل رتبة العضو. تأكد من أن البوت مشرف ويمتلك الصلاحيات الكافية.'
                });
            } catch (sendError) {
                console.error('Error sending error message:', sendError);
            }
        }
    }
}

// دالة لمعالجة اكتشاف تنزيل الرتبة تلقائياً (عندما يقوم مشرف بتنزيل آخر)
async function handleDemotionEvent(sock, groupId, participants, author) {
    try {
        if (!Array.isArray(participants) || participants.length === 0) {
            return;
        }

        await new Promise(resolve => setTimeout(resolve, 1000));

        const demotedUsernames = await Promise.all(participants.map(async jid => {
            const jidString = typeof jid === 'string' ? jid : (jid.id || jid.toString());
            return `@${jidString.split('@')[0]}`;
        }));

        let demotedBy;
        let mentionList = participants.map(jid => {
            return typeof jid === 'string' ? jid : (jid.id || jid.toString());
        });

        if (author && author.length > 0) {
            const authorJid = typeof author === 'string' ? author : (author.id || author.toString());
            demotedBy = `@${authorJid.split('@')[0]}`;
            mentionList.push(authorJid);
        } else {
            demotedBy = 'النظام';
        }

        await new Promise(resolve => setTimeout(resolve, 1000));

        const demotionMessage = `*『 تنبيه تنزيل رتبة 』*\n\n` +
            `👤 *العضو الذي تم تنزيل رتبته:* \n` +
            `${demotedUsernames.map(name => `• ${name}`).join('\n')}\n\n` +
            `👑 *بواسطة:* ${demotedBy}\n\n` +
            `📅 *التاريخ:* ${new Date().toLocaleString('ar-EG')}`;
        
        await sock.sendMessage(groupId, {
            text: demotionMessage,
            mentions: mentionList
        });
    } catch (error) {
        console.error('Error handling demotion event:', error);
    }
}

module.exports = { demoteCommand, handleDemotionEvent };
