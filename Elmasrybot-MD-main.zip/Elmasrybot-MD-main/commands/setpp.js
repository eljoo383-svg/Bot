const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const isOwnerOrSudo = require('../lib/isOwner');

async function setProfilePicture(sock, chatId, msg) {
    try {
        const senderId = msg.key.participant || msg.key.remoteJid;
        const isOwner = await isOwnerOrSudo(senderId, sock, chatId);
        
        // التحقق من هوية المطور
        if (!msg.key.fromMe && !isOwner) {
            await sock.sendMessage(chatId, { 
                text: '🚫 *تـصـريـح مـرفـوض* 🚫\n\nعذراً يا وحش، هذا الأمر خاص بـ *مـطـور الـبـوت* فقط! 👑✨' 
            });
            return;
        }

        // التحقق من وجود رد على رسالة
        const quotedMessage = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!quotedMessage) {
            await sock.sendMessage(chatId, { 
                text: '⚠️ *تـنـبيه هـام* ⚠️\n\nمن فضلك قم بالرد على "صورة" باستخدام الأمر *.setpp* لتغيير واجهة البوت! 📸💎' 
            });
            return;
        }

        // التأكد أن الرد عبارة عن صورة
        const imageMessage = quotedMessage.imageMessage || quotedMessage.stickerMessage;
        if (!imageMessage) {
            await sock.sendMessage(chatId, { 
                text: '❌ *خـطأ فـي الـوسـائـط* ❌\n\nيجب أن يكون الرد على "صورة" صالحة، الملصقات أو الفيديوهات لا تصلح كصورة ملف شخصي! 🖼️⚙️' 
            });
            return;
        }

        // إنشاء مجلد مؤقت إذا لم يكن موجوداً
        const tmpDir = path.join(process.cwd(), 'tmp');
        if (!fs.existsSync(tmpDir)) {
            fs.mkdirSync(tmpDir, { recursive: true });
        }

        // تحميل الصورة
        const stream = await downloadContentFromMessage(imageMessage, 'image');
        let buffer = Buffer.from([]);
        
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        const imagePath = path.join(tmpDir, `profile_${Date.now()}.jpg`);
        
        // حفظ الصورة مؤقتاً
        fs.writeFileSync(imagePath, buffer);

        // تحديث صورة الملف الشخصي
        await sock.updateProfilePicture(sock.user.id, { url: imagePath });

        // حذف الملف المؤقت بعد التحديث
        fs.unlinkSync(imagePath);

        // رسالة النجاح الفخمة
        await sock.sendMessage(chatId, { 
            text: '✅ *تـم تـحـديـث الـمـظـهـر بـنـجـاح* ✅\n' +
                  '━━━━━━━━━━━━━━━━━━━━\n\n' +
                  '✨ *تـم تـغييـر صـورة الـبـروفـايل الـخـاصـة بـالـ VIP*\n' +
                  '🖼️ الـشـكـل الـجـديـد أصـبـح مـفـعـلاً الآن!\n\n' +
                  '━━━━━━━━━━━━━━━━━━━━\n' +
                  '💎 *VIP BOT | دائـمـاً فـي تـألق* 💎'
        });

    } catch (error) {
        console.error('Error in setpp command:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ *عـذراً.. فـشـلـ التـحـديـث!* ❌\n\nحدث خطأ أثناء معالجة الصورة، تأكد من جودتها وحاول مرة أخرى! 🛠️🌀' 
        });
    }
}

module.exports = setProfilePicture;
