const axios = require('axios');

// إعدادات الـ VIP والـ Newsletter الاحترافية
const vipConfig = { 
    contextInfo: { 
        forwardingScore: 999, 
        isForwarded: true, 
        forwardedNewsletterMessageInfo: { 
            newsletterJid: '120363405610374694@newsletter', 
            newsletterName: '💎 VIP NEWS SOURCE', 
            serverMessageId: 1 
        } 
    } 
};

module.exports = async function (sock, chatId) {
    try {
        const apiKey = 'dcd720a6f1914e2d9dba9790c188c08c'; 
        const response = await axios.get(`https://newsapi.org/v2/top-headlines?country=eg&apiKey=${apiKey}`);
        const articles = response.data.articles.slice(0, 5); 

        // عنوان الرسالة بشكل فخم
        let newsMessage = '👑 *نـشـرة أخـبـار الـ VIP* 👑\n';
        newsMessage += '⚡ _حصرياً لك يا وحش من قلب الحدث_ ⚡\n\n';
        newsMessage += '┏━━━━━━━━━━━━━━━━━━┓\n';

        articles.forEach((article, index) => {
            const emojis = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣'];
            newsMessage += `\n${emojis[index]} ◈ *${article.title.trim()}*\n`;
            newsMessage += `\n📖 ➪ ${article.description ? article.description.trim() : 'لا توجد تفاصيل إضافية متاحة حالياً..'} 🔍\n`;
            newsMessage += `\n🔗 ➪ _للمزيد:_ ${article.url}\n`;
            newsMessage += '\n───────────────────';
        });

        newsMessage += '\n┗━━━━━━━━━━━━━━━━━━┛\n\n';
        newsMessage += '💎 *VIP BOT | دايماً سابق بخطوة* 💎';

        await sock.sendMessage(chatId, { 
            text: newsMessage, 
            ...vipConfig 
        });

    } catch (error) {
        console.error('Error fetching news:', error);
        await sock.sendMessage(chatId, { 
            text: '⚠️ *عذراً عزيزي الـ VIP* ⚠️\n\nحدث خطأ تقني أثناء جلب الأخبار. ⚙️\nبرجاء المحاولة مرة أخرى لاحقاً. ✨',
            ...vipConfig 
        });
    }
};
