const fs = require('fs');
// تحديث المعرف للمتابعة (Newsletter)
const channelInfo = { contextInfo: { forwardingScore: 999, isForwarded: true, forwardedNewsletterMessageInfo: { newsletterJid: '120363405610374694@newsletter', newsletterName: 'VIP SYSTEM', serverMessageId: 1 } } };
const isAdmin = require('../lib/isAdmin');
const { isSudo } = require('../lib/index');

async function banCommand(sock, chatId, message) {
    const isGroup = chatId.endsWith('@g.us');
    if (isGroup) {
        const senderId = message.key.participant || message.key.remoteJid;
        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);
        if (!isBotAdmin) {
            await sock.sendMessage(chatId, { text: '⚠️ | يا غالي لازم ترفع البوت "مشرف" (Admin) الأول عشان أقدر أطرد حد! 🛡️', ...channelInfo }, { quoted: message });
            return;
        }
        if (!isSenderAdmin && !message.key.fromMe) {
            await sock.sendMessage(chatId, { text: '❌ | معلش يا حب، الأمر ده خاص بالمشرفين (Admins) بس! 👑', ...channelInfo }, { quoted: message });
            return;
        }
    } else {
        const senderId = message.key.participant || message.key.remoteJid;
        const senderIsSudo = await isSudo(senderId);
        if (!message.key.fromMe && !senderIsSudo) {
            await sock.sendMessage(chatId, { text: '🚫 | للأسف، صاحب البوت بس هو اللي يقدر يستخدم "البان" هنا! ✨', ...channelInfo }, { quoted: message });
            return;
        }
    }
    let userToBan;
    
    if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        userToBan = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
    }
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToBan = message.message.extendedTextMessage.contextInfo.participant;
    }
    
    if (!userToBan) {
        await sock.sendMessage(chatId, { 
            text: '📌 | من فضلك اعمل "منشن" للمستخدم أو رد على رسالته عشان أديله بان! 🏷️', 
            ...channelInfo 
        });
        return;
    }

    try {
        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        if (userToBan === botId || userToBan === botId.replace('@s.whatsapp.net', '@lid')) {
            await sock.sendMessage(chatId, { text: '😂 | عايز تديني بان وأنا اللي شغال؟ متبقاش قفوش بقى! 🛡️', ...channelInfo }, { quoted: message });
            return;
        }
    } catch {}

    try {
        const bannedUsers = JSON.parse(fs.readFileSync('./data/banned.json'));
        if (!bannedUsers.includes(userToBan)) {
            bannedUsers.push(userToBan);
            fs.writeFileSync('./data/banned.json', JSON.stringify(bannedUsers, null, 2));
            
            await sock.sendMessage(chatId, { 
                text: `✅ | تم بنجاح! المستخدم @${userToBan.split('@')[0]} أخد "بان" من السيستم بنجاح.. مع السلامة يا بطل! 👋🔥`,
                mentions: [userToBan],
                ...channelInfo 
            });
        } else {
            await sock.sendMessage(chatId, { 
                text: `⚠️ | يا غالي المستخدم ده أصلاً محظور (Banned) من بدري! 🚫`,
                mentions: [userToBan],
                ...channelInfo 
            });
        }
    } catch (error) {
        console.error('Error in ban command:', error);
        await sock.sendMessage(chatId, { text: '❌ | حصلت مشكلة وأنا بحاول أدي البان، جرب تاني كمان شوية! ⚙️', ...channelInfo });
    }
}

module.exports = banCommand;
