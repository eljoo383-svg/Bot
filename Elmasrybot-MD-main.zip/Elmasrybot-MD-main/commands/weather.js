const axios = require('axios');

module.exports = async function (sock, chatId, message, city) {
    try {
        const apiKey = '4902c0f2550f58298ad4146a92b65e10'; 
        const response = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric&lang=ar`);
        const weather = response.data;

        // صياغة الرسالة بشكل احترافي VIP
        const weatherText = `
*╭━━━〔 ☁️ حـالة الطقـس ☁️ 〕━━━╮*

*📍 المـدينة:* ${weather.name}
*🌡️ الحرارة:* ${weather.main.temp}°C
*✨ الوصـف:* ${weather.weather[0].description}
*💧 الرطـوبة:* ${weather.main.humidity}%
*🌬️ الريـاح:* ${weather.wind.speed} m/s

*╰━━━━━━━━━━━━━━━━━━━━╯*
*تم التحديث بواسطة بوت VIP 💎*`;

        await sock.sendMessage(chatId, { text: weatherText }, { quoted: message });
    } catch (error) {
        console.error('Error fetching weather:', error);
        
        // رسالة خطأ بشكل لائق
        const errorText = `
*❌ عـذراً عزيزي..*
لم أستطع العثور على بيانات مدينة *"${city}"*
تأكد من كتابة الاسم بشكل صحيح ✍️✨`;
        
        await sock.sendMessage(chatId, { text: errorText }, { quoted: message });
    }
};
